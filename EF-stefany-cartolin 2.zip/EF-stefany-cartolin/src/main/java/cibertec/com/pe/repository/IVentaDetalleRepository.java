package cibertec.com.pe.repository;

import cibertec.com.pe.model.VentaDetalle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IVentaDetalleRepository extends JpaRepository<VentaDetalle, Integer> {
}
