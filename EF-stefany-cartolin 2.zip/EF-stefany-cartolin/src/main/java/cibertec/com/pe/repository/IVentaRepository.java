package cibertec.com.pe.repository;

import cibertec.com.pe.model.Venta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IVentaRepository extends JpaRepository<Venta, Integer> {
}
