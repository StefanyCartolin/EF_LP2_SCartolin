package cibertec.com.pe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EfStefanyCartolinApplication {

	public static void main(String[] args) {
		SpringApplication.run(EfStefanyCartolinApplication.class, args);
	}

}
